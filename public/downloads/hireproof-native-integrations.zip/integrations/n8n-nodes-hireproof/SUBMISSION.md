# n8n Community Node Submission Checklist

- [ ] Package name is `n8n-nodes-hireproof`.
- [ ] `package.json` includes the `n8n-community-node-package` keyword.
- [ ] `package.json` includes `n8n.credentials` and `n8n.nodes` entries.
- [ ] `npm run test` passes.
- [ ] A self-hosted n8n install can load the package.
- [ ] Screenshot captured for credential setup.
- [ ] Screenshot captured for `Run Audit`.
- [ ] Screenshot captured for `Run Async Audit`.
- [ ] README describes account-issued/private API keys and live credential boundaries.
- [x] npm publish completed with the maintainer account: `https://www.npmjs.com/package/n8n-nodes-hireproof`.
- [ ] n8n community verification submitted after npm publish.
